package com.mvc.controller;

import com.mvc.dao.OrderDAO;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet("/placeorder")
public class PlaceOrderServlet extends HttpServlet {

    protected void doPost(
            HttpServletRequest req,
            HttpServletResponse res
    ) throws ServletException, IOException {

        int customerId =
                Integer.parseInt(req.getParameter("customerId"));

        String orderDate =
                req.getParameter("orderDate");

        OrderDAO dao = new OrderDAO();

        dao.placeOrder(customerId, orderDate);

        res.getWriter().println("Order Placed");
    }
}
