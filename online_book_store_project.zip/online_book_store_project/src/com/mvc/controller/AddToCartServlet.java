package com.mvc.controller;

import com.mvc.dao.BookDAO;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet("/addtocart")
public class AddToCartServlet extends HttpServlet {

    protected void doPost(
            HttpServletRequest req,
            HttpServletResponse res
    ) throws ServletException, IOException {

        int orderId =
                Integer.parseInt(req.getParameter("orderId"));

        int bookId =
                Integer.parseInt(req.getParameter("bookId"));

        int quantity =
                Integer.parseInt(req.getParameter("quantity"));

        BookDAO dao = new BookDAO();

        dao.addToCart(orderId, bookId, quantity);

        res.getWriter().println("Book Added To Cart");
    }
}
