package com.mvc.controller;

import com.mvc.dao.OrderDAO;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet("/history")
public class OrderHistoryServlet extends HttpServlet {

    protected void doGet(
            HttpServletRequest req,
            HttpServletResponse res
    ) throws ServletException, IOException {

        OrderDAO dao = new OrderDAO();

        dao.displayOrderHistory();

        res.getWriter().println("Order History Displayed");
    }
}
