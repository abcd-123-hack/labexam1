package com.mvc.utility;

import java.io.FileWriter;

public class LoggerUtil {

    public static void log(String message) {

        try {

            FileWriter fw =
                    new FileWriter("transaction_log.txt", true);

            fw.write(message + "\n");

            fw.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
