package com.mvc.dao;

import com.mvc.utility.LoggerUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class OrderDAO {

    public void placeOrder(
            int customerId,
            String orderDate
    ) {

        try {

            Connection con =
                    DbConnection.getConnection();

            String sql =
                    "INSERT INTO Orders(customer_id, order_date) VALUES (?, ?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, customerId);
            ps.setString(2, orderDate);

            ps.executeUpdate();

            LoggerUtil.log(
                    "Order placed by Customer ID = "
                            + customerId
            );

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void displayOrderHistory() {

        try {

            Connection con =
                    DbConnection.getConnection();

            String sql = "SELECT * FROM Orders";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                System.out.println(
                        rs.getInt("order_id")
                        + " "
                        + rs.getInt("customer_id")
                        + " "
                        + rs.getDate("order_date")
                );
            }

            LoggerUtil.log("Displayed Order History");

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
