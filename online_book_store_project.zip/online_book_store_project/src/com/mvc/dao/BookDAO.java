package com.mvc.dao;

import com.mvc.utility.LoggerUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class BookDAO {

    public void addToCart(
            int orderId,
            int bookId,
            int quantity
    ) {

        try {

            Connection con =
                    DbConnection.getConnection();

            String sql =
                    "INSERT INTO Order_Items(order_id, book_id, quantity) VALUES (?, ?, ?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, orderId);
            ps.setInt(2, bookId);
            ps.setInt(3, quantity);

            ps.executeUpdate();

            LoggerUtil.log(
                    "Book added to cart : Book ID = "
                            + bookId
            );

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
