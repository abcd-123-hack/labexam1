/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.util;

/**
 *
 * @author MSIS
 */


import java.io.IOException;
import java.util.logging.*;

public class Loggerutil {
    private static Logger logger = Logger.getLogger("LibraryLogger");

    static {
        try {
            FileHandler fh = new FileHandler("library.log", true);
            fh.setFormatter(new SimpleFormatter());
            logger.addHandler(fh);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Logger getLogger() {
        return logger;
    }
}  

