/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.controller;





import com.mycompany.model.IssueDAO;
import com.mycompany.util.Loggerutil;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Logger;

public class ReturnBookServlet extends HttpServlet {

    private static final Logger logger = Loggerutil.getLogger();

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        try {
            int issueId = Integer.parseInt(req.getParameter("issueId"));
            int bookId = Integer.parseInt(req.getParameter("bookId"));

            IssueDAO dao = new IssueDAO();
            dao.returnBook(issueId, bookId);

            logger.info("Book " + bookId + " returned (Issue ID: " + issueId + ")");

            // ✅ Success message
            out.println("<h2 style='color:green;'>✅ Book Returned Successfully!</h2>");
            out.println("<a href='index.html'>Go Home</a>");

        } catch (Exception e) {

            logger.severe("Return Error: " + e.getMessage());
            e.printStackTrace();

            // ❌ Error message
            out.println("<h2 style='color:red;'>❌ Error while returning book</h2>");
            out.println("<p>" + e.getMessage() + "</p>");
            out.println("<a href='return.jsp'>Go Back</a>");
        }
    }
}
 
