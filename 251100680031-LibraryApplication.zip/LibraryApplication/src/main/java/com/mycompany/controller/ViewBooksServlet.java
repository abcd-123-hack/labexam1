/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.controller;




import com.mycompany.model.Book;
import com.mycompany.model.BookDAO;
import com.mycompany.util.Loggerutil;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.util.logging.Logger;

public class ViewBooksServlet extends HttpServlet {

    private static final Logger logger = Loggerutil.getLogger();

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        try {
            BookDAO dao = new BookDAO();
            List<Book> books = dao.getAvailableBooks();

            req.setAttribute("books", books);

            // ✅ FIX PATH (see next issue)
            req.getRequestDispatcher("viewBooks.jsp").forward(req, res);

            logger.info("Displayed available books");

        } catch (Exception e) {

            logger.severe("Error fetching books: " + e.getMessage());
            e.printStackTrace();

            // ✅ Show error directly instead of redirect
            res.setContentType("text/html");
            PrintWriter out = res.getWriter();

            out.println("<h2 style='color:red;'>Error loading books</h2>");
            out.println("<p>" + e.getMessage() + "</p>");
        }
    }
}

