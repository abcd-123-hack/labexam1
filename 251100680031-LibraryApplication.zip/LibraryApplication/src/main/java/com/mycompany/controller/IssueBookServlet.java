/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.controller;




import com.mycompany.model.IssueDAO;
import com.mycompany.util.Loggerutil;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Logger;

public class IssueBookServlet extends HttpServlet {

    private static final Logger logger = Loggerutil.getLogger();

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        try {
            int bookId = Integer.parseInt(req.getParameter("bookId"));
            int memberId = Integer.parseInt(req.getParameter("memberId"));

            IssueDAO dao = new IssueDAO();
            dao.issueBook(bookId, memberId);

            logger.info("Book " + bookId + " issued to member " + memberId);

            // ✅ Success message directly
            out.println("<h2 style='color:green;'>✅ Book Issued Successfully!</h2>");
            out.println("<a href='index.html'>Go Home</a>");

        } catch (Exception e) {

            logger.severe("Issue Error: " + e.getMessage());
            e.printStackTrace();

            // ❌ Error message directly
            out.println("<h2 style='color:red;'>❌ Error while issuing book</h2>");
            out.println("<p>" + e.getMessage() + "</p>");
            out.println("<a href='issue.jsp'>Go Back</a>");
        }
    }
}


