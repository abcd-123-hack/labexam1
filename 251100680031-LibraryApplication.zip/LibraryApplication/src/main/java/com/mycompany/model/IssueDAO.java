/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.model;

/**
 *
 * @author MSIS
 */


import com.mycompany.util.DBConnection;
import java.sql.*;

public class IssueDAO {

    public void issueBook(int bookId, int memberId) throws Exception {
        Connection con = DBConnection.getConnection();

        // Insert issue record
        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO Issue(book_id, member_id, issue_date) VALUES (?, ?, NOW())"
        );
        ps.setInt(1, bookId);
        ps.setInt(2, memberId);
        ps.executeUpdate();

        // Reduce available copies
        PreparedStatement ps2 = con.prepareStatement(
            "UPDATE Book SET available_copies = available_copies - 1 WHERE book_id = ?"
        );
        ps2.setInt(1, bookId);
        ps2.executeUpdate();
    }

    public void returnBook(int issueId, int bookId) throws Exception {
        Connection con = DBConnection.getConnection();

        // Update return date
        PreparedStatement ps = con.prepareStatement(
            "UPDATE Issue SET return_date = NOW() WHERE issue_id = ?"
        );
        ps.setInt(1, issueId);
        ps.executeUpdate();

        // Increase available copies
        PreparedStatement ps2 = con.prepareStatement(
            "UPDATE Book SET available_copies = available_copies + 1 WHERE book_id = ?"
        );
        ps2.setInt(1, bookId);
        ps2.executeUpdate();
    }
} 

