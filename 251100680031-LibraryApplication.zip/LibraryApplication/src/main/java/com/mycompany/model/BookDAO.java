/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.model;

/**
 *
 * @author MSIS
 */


import com.mycompany.util.DBConnection;
import java.sql.*;
import java.util.*;

public class BookDAO {

    public List<Book> getAvailableBooks() throws Exception {
        List<Book> list = new ArrayList<>();
        Connection con = DBConnection.getConnection();

        String query = "SELECT * FROM Book WHERE available_copies > 0";
        PreparedStatement ps = con.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Book b = new Book();
            b.setBookId(rs.getInt("book_id"));
            b.setTitle(rs.getString("title"));
            b.setAuthor(rs.getString("author"));
            b.setPublisher(rs.getString("publisher"));
            b.setAvailableCopies(rs.getInt("available_copies"));
            list.add(b);
        }
        return list;
    }
}

