<%-- 
    Document   : issue
    Created on : 07-Apr-2026, 4:50:04 am
    Author     : MSIS
--%>


<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Issue Book</title>
</head>
<body>

    <h2>Issue Book</h2>

    <form action="IssueBookServlet" method="post">
        <label>Book ID:</label>
        <input type="text" name="bookId" required><br><br>

        <label>Member ID:</label>
        <input type="text" name="memberId" required><br><br>

        <input type="submit" value="Issue Book">
    </form>

</body>
</html>
