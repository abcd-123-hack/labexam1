<%-- 
    Document   : return
    Created on : 07-Apr-2026, 4:52:59 am
    Author     : MSIS
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Return Book</title>
</head>
<body>

    <h2>Return Book</h2>

    <form action="ReturnBookServlet" method="post">
        <label>Issue ID:</label>
        <input type="text" name="issueId" required><br><br>

        <label>Book ID:</label>
        <input type="text" name="bookId" required><br><br>

        <input type="submit" value="Return Book">
    </form>

</body>
</html>
