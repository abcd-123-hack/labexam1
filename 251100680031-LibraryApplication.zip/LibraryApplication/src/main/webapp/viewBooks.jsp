<%-- 
    Document   : ViewBooks
    Created on : 07-Apr-2026, 4:55:02 am
    Author     : MSIS
--%>

<%@page import="java.util.List"%>
<%@page import="com.mycompany.model.Book"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Available Books</title>
</head>
<body>

<h2>📚 Available Books</h2>

<table border="1" cellpadding="10">
<tr>
    <th>Title</th>
    <th>Author</th>
    <th>Publisher</th>
    <th>Available Copies</th>
</tr>

<%
    List<Book> books = (List<Book>) request.getAttribute("books");

    if (books != null && !books.isEmpty()) {
        for(Book b : books){
%>
<tr>
    <td><%= b.getTitle() %></td>
    <td><%= b.getAuthor() %></td>
    <td><%= b.getPublisher() %></td>
    <td><%= b.getAvailableCopies() %></td>
</tr>
<%
        }
    } else {
%>
<tr>
    <td colspan="4">No books available</td>
</tr>
<%
    }
%>

</table>

</body>
</html>